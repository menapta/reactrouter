import React from 'react';

function About() {
  return <h2>About Page 777</h2>;
}

export default About;